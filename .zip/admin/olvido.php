<?php
include 'conexion/conexion.php';
 ?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie-edge">
<link rel="stylesheet" href="css/materialize.min.css">
<link rel="stylesheet" href="../admin/css/materialize.min.css">
<link  href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link  href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
  <main>
    <div class="row">
      <div class="input-field s12 center">
       <a title="Inicio" href="https://www.redinmobiliarias.com.ar"><img src="img/principal.png" width="300"></a>

      </div>

    </div>
    <div class="container"   >
      <div class="row">
        <div class="col s12">
          <div class="card z-depth-5 ">
            <div class="card-content"style="background: linear-gradient(rgb(85, 147, 241), rgb(228, 236, 241), rgb(243, 179, 96));">
             <form  action="cambiar.php" method="post" autocomplete="off">
              <h5>Cambiar Password / Usuario</h5><br>

              <div class="input-field">
                <input type="email" name="correo"  id="correo" >

                <label for="correo">Correo electronico</label>

              </div>
              <div class="validacionCorreo"></div>
              <br>
              <div class="input-field center">
               <button type="submit" class="btn waves-effect waves-light">Cambiar</button>
               </div>


            </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script
      src="https://code.jquery.com/jquery-3.4.1.min.js"
      integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
      crossorigin="anonymous"></script>
      <script src="../admin/js/materialize.min.js"></script>



    <script src="js/validacionCorreo.js"></script>
</body>
</html>
