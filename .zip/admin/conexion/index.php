<?php
header('location:../');
 ?>
