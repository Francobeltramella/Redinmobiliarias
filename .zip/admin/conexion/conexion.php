<?php

@session_start();

$con = new mysqli("localhost", "u351422869_ri", "12345678", "u351422869_ri");
$con->set_charset('utf8');

?>
