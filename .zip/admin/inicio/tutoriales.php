<?php include '../extend/header.php' ?>
<div class="container">
<h4>TUTORIALES</h4>
<br>
<h5>Carga de Propiedades</h5>
<p>* SOLO SE PUEDEN CARGAR 5 IMAGENES POR PROPIEDAD (APARTE DE LA PRINCIPAL)</p>
<p>* SOLO SE ACEPTAN FORMATOS PNG, JPG, JPEG</p>
<video src="../img/Cargaprop.m4v" width=420  height=340 controls poster="vistaprevia.jpg">
Lo sentimos. Este vídeo no puede ser reproducido en tu navegador.<br>
La versión descargable está disponible en <a href="URL">Enlace</a>. 
</video>


</div>