<?php include '../conexion/conexion.php';
if ($_SERVER['REQUEST_METHOD']=='POST'){
    $dias= htmlentities($_POST['dias']);
 $apertura= htmlentities($_POST['apertura']);
  $cierre=htmlentities($_POST['cierre']);
  $sitioweb=htmlentities($_POST['sitioweb']);
  $instagram=htmlentities($_POST['instagram']);
  $facebook=htmlentities($_POST['facebook']);

  $id=htmlentities($_POST['id']);




  $up=$con->prepare("UPDATE datasinmo SET dias=?, apertura=?,cierre=?, sitioweb=?, instagram=?, facebook=? WHERE id=?");
  $up->bind_param('ssssssi',$dias,$apertura,$cierre,$sitioweb, $instagram, $facebook,$id );

 if ($up->execute()) {
    header('location:../extend/alert.php?msj=Cliente actualizado&c=perfil&p=in&t=success');
  }else{
    header('location:../extend/alert.php?msj=El cliente no pudo ser actualizado&c=perfil&p=in&t=error');
  }
$up->close();
  $con->close();



  }else{
  header('location:../extend/alert.php?msj=Utiliza el formulario&c=cli&p=in&t=error');
  }

 ?>
