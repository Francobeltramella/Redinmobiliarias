<?php include '../extend/header.php';
$id=htmlentities($_GET['id']);

$sel=$con->prepare("SELECT * FROM inquilinos WHERE id= ?");
$sel->bind_param('i',$id);
$sel->execute();
$res=$sel->get_result();

if($f=$res->fetch_assoc()){}


 ?>


<div class="row">
  <div class="col s12">
    <div class="card">
      <div class="card-content">
        <span class="card-title">Edicion de inquilinos</span>
        <form class="form" action="up_inquilino.php" method="post" autocomplete=off >
          <input type="hidden" name="id" value="<?php echo $id ?>">
          <div class="input-field">
            <input type="text" name="nombre" value="<?php echo $f['nombre'] ?>"  title="Solo letras" pattern="[A-Z/s ]+"  id="nombre" onblur="may(this.value, this.id)"  >
            <label for="nombre">Nombre</label>
          </div>
          <div class="input-field">
            <input type="text" name="apellido" value="<?php echo $f['apellido'] ?>">
            <label for="apellido">Apellido</label>
            </div>
            <div class="input-field">
              <input type="number" name="dni" value="<?php echo $f['dni'] ?>">

            </div>
          <div class="input-field">
            <input type="text" name="locacion"   value="<?php echo $f['locacion'] ?>"  id="locacion" onblur="may(this.value, this.id)"  >
            <label for="locacion">Dirección</label>
          </div>
          <div class="input-field">
            <input type="number" name="telefono" value="<?php echo $f['telefono'] ?>"  id="telefono"  >
            <label for="telefono">Telefono</label>
          </div>
          <div class="input-field">
            <input type="email" name="correo" value="<?php echo $f['correo'] ?>"  id="correo"   >
            <label for="correo">Correo</label>

          </div>
          <p>Constrato desde :</p>
          <div class="input-field ">
            <input type="date" name="desde"   value="<?php echo $f['desde'] ?>" id="desde">
            <label for=""></label>
          </div>
          <p> Hasta :</p>
          <div class="input-field ">
          <input type="date" name="hasta"  value="<?php echo $f['hasta'] ?>"  id="hasta">
            <label for=""></label>
          </div>
          <button type="submit" class="btn" >Guardar</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
$sel->close();
$con->close();
include '../extend/scripts.php'; ?>
