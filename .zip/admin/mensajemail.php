<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie-edge">
<link rel="stylesheet" href="css/materialize.min.css">
<link  href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body    >



  <main>
      <div class="row">
        <div class="input-field s12 center">
         <a title="Inicio" href="https://www.redinmobiliarias.com.ar"><img src="img/principal.png" width="300"></a>

        </div>

      </div>
      <div class="container"   >
        <div class="row">
          <div class="col s12">
            <div class="card z-depth-5 ">
              <div class="card-content"style="background: linear-gradient(rgb(85, 147, 241), rgb(228, 236, 241), rgb(243, 179, 96));">
              <span class="card-title"><center> PERFECTO! </center></span>
              <h5>Recibira un link en el mail ingresado anteriormente para el cambio de contraeña...</h5>
             

            </div>

          </div>

        </div>

      </div>

    </div>

  </main>
 
</body>
</html>
